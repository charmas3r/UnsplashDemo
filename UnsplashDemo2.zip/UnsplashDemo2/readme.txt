Unsplash Demo Readme

*Uses Unofficial Unsplash API android library
https://github.com/KeenenCharles/AndroidUnplash

*Uses Android Palette API to dynamically change background based on image

BUGS
*Sometimes Textswatch returns null which means the palette api cannot parse
the bitmap. 
*Unsplash API can only call up to 30 photos at a time so recycler is holding only
a single of photos retrieved from unsplash.com. This could be fixed with pagination.

Further questions, do not hesitate to ask.
-Evan -> evansmith0115@gmail.com